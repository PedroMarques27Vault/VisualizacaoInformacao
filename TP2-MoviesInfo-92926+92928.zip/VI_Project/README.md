# VI_Project
Run with:
python3 -m http.server 8888

Then open http://localhost:8888/index.html
